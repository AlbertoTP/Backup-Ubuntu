# frozen_string_literal: false
require 'rubygems/resolver/molinillo/lib/molinillo'
